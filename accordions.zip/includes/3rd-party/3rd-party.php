<?php
if ( ! defined('ABSPATH')) exit;  // if direct access


require_once( accordions_plugin_dir . 'includes/3rd-party/arconix-faq/functions-data-import.php');
require_once( accordions_plugin_dir . 'includes/3rd-party/easy-accordion-free/functions-data-import.php');
require_once( accordions_plugin_dir . 'includes/3rd-party/responsive-accordion-and-collapse/functions-data-import.php');
require_once( accordions_plugin_dir . 'includes/3rd-party/responsive-tabs/functions-data-import.php');
require_once( accordions_plugin_dir . 'includes/3rd-party/easy-responsive-tabs/functions-data-import.php');
require_once( accordions_plugin_dir . 'includes/3rd-party/everest-tab-lite/functions-data-import.php');
require_once( accordions_plugin_dir . 'includes/3rd-party/quick-and-easy-faqs/functions-data-import.php');
require_once( accordions_plugin_dir . 'includes/3rd-party/shortcodes-ultimate/functions-data-import.php');
require_once( accordions_plugin_dir . 'includes/3rd-party/sp-faq/functions-data-import.php');
require_once( accordions_plugin_dir . 'includes/3rd-party/squelch-tabs-and-accordions-shortcodes/functions-data-import.php');
require_once( accordions_plugin_dir . 'includes/3rd-party/tabby-responsive-tabs/functions-data-import.php');
require_once( accordions_plugin_dir . 'includes/3rd-party/ultimate-faqs/functions-data-import.php');
require_once( accordions_plugin_dir . 'includes/3rd-party/tabs-shortcode/functions-data-import.php');
require_once( accordions_plugin_dir . 'includes/3rd-party/wonderplugin-tabs-trial/functions-data-import.php');
require_once( accordions_plugin_dir . 'includes/3rd-party/tabs-pro/functions-data-import.php');
require_once( accordions_plugin_dir . 'includes/3rd-party/accordion-shortcodes/functions-data-import.php');
require_once( accordions_plugin_dir . 'includes/3rd-party/wc-shortcodes/functions-data-import.php');
require_once( accordions_plugin_dir . 'includes/3rd-party/wp-shortcode/functions-data-import.php');
require_once( accordions_plugin_dir . 'includes/3rd-party/helpie-faq/functions-data-import.php');
require_once( accordions_plugin_dir . 'includes/3rd-party/meks-flexible-shortcodes/functions-data-import.php');