<?php
if (!defined('ABSPATH')) exit;  // if direct access

function accordion_post_query_items($args) {}
function accordion_terms_query_item($args) {}
